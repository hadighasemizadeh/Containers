#include <iostream>
#include "formula.hpp"
#include "project_info.hpp"

int main() 
{
    std::cout << PROJECT_NAME << " v" << PROJECT_VERSION << " has started.\n";
    std::cout << "Square root of 2 is " << formula::square(2) << std::endl;

    return 0;
}