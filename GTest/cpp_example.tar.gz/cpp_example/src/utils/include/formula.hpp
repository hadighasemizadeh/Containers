#ifndef EXAMPLEPROJECT_FORMULA_HPP
#define EXAMPLEPROJECT_FORMULA_HPP

class formula 
{
public:
    static int square(int arg1);
};

#endif //EXAMPLEPROJECT_FORMULA_HPP