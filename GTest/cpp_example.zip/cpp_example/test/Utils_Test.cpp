#include "gtest/gtest.h"
#include "formula.hpp"

TEST(blaTest, test1) 
{
    EXPECT_EQ (formula::square (0),  0);
    EXPECT_EQ (formula::square (10), 100);
    EXPECT_EQ (formula::square (20), 400);
}