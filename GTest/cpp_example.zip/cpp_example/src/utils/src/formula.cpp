#include "formula.hpp"

int formula::square(int arg1) 
{
    return arg1 * arg1;
}
